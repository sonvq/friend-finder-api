/**
 * Content script in context of a google search page
 * @author vietnh
 */
// Listen to event message
window.addEventListener('message', function onMessage(e) {
  // When a search result is occured
  if (typeof e.data === 'object' && e.data.type === 'sr') {
    var domains = getAllDomainsFromSearchResults();
    if (domains) {
      var http = new XMLHttpRequest();
      var params = [];
      for (var key in domains) {
        params.push("domains=" + domains[key]);
      }
      params = params.join('&');
      http.open("POST", bogoConfig.v5ApiUrl, true);
      http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      http.onreadystatechange = function() {
        if(http.readyState == 4 && http.status == 200) {
          var response = JSON.parse(http.responseText);
          // If there is no error responded from api
          if (! response.code) {
            // Get the base bogo logo
            var baseLogo = response.data.baseLogo;
            var domainData = [];
            for (let key in response.data.resultData) {
              domainData[response.data.resultData[key].domain] = response.data.resultData[key];
            }

            for (let key in domains) {
              if (typeof domainData[domains[key]] === 'undefined') {
                continue;
              } else {
                var upTo = domainData[domains[key]] && domainData[domains[key]].cashBack && domainData[domains[key]].cashBack.upTo ? 'Up to ' : '';
                var cashBack = domainData[domains[key]] && domainData[domains[key]].cashBack && domainData[domains[key]].cashBack.cashBack ?
                  domainData[domains[key]].cashBack.cashBack + domainData[domains[key]].cashBack.currency : '';

                var result = document.querySelectorAll('.r a')[key];
                if (result.className != 'l') {
                  var bogoSearch = document.createElement('div');
                  bogoSearch.className = 'bogo-search';
                  var bogoSearchIcon = document.createElement('div');
                  bogoSearchIcon.className = 'bogo-search-icon';
                  var bogoSearchText = document.createElement('span');
                  bogoSearchText.className = 'bogo-search-text';

                  if (cashBack) {
                    bogoSearchText.appendChild(document.createTextNode(upTo + cashBack + ' ' + bogoConfig.text.cashBack));
                  } else {
                    bogoSearchText.appendChild(document.createTextNode(bogoConfig.text.availableCoupons + ': ' + domainData[domains[key]].couponsAvailable));
                  }

                  bogoSearchIcon.appendChild(bogoSearchText);
                  bogoSearch.appendChild(bogoSearchIcon);
                  result.insertBefore(bogoSearch, result.firstChild);
                }
              }
            }

            // Add style for message we added to google search results
            addCssStyleToGoogleSearch();
          }
        }
      }
      http.send(params);
    }
  }
});

/**
 * Get all domains of results from a google search page
 */
function getAllDomainsFromSearchResults()
{
  var domains = [];
  var results = document.querySelectorAll('.r a');

  if (results.length) {
    for (var key in results) {
      var url = results[key].href;
      if (typeof url != 'undefined') {
        var domain = url.match(/^[\w-]+:\/{2,}\[?([\w\.:-]+)\]?(?::[0-9]*)?/)[1];
        domain = domain.indexOf('www.') === 0 ? domain.replace('www.', '') : '';
      }

      domains.push(domain);
    }
  }

  return domains;
}

/**
 * Add style for message we added to google search results
 */
function addCssStyleToGoogleSearch()
{
  var bogoStyle = document.createElement('style');
  bogoStyle.appendChild(document.createTextNode('.bogo-search-icon {\
    display: inline-block!important;\
    width: 33px!important;\
    height: 17px!important;\
    margin: 0!important;\
    padding: 0!important;\
    background-size: 100%!important;\
    background-position: center;\
    background-image: url("https://www.bogo.vn/static/images/bogo-logo.svg") !important;\
    background-size: cover;\
  }\
  .bogo-search-text {\
    font-family: Arial,sans-serif!important;\
    font-size: 14px!important;\
    font-weight: 400!important;\
    line-height: 16px!important;\
    color: #f30!important;\
    margin: 0 0 2px 39px!important;\
    display: inline-block!important;\
    vertical-align: top!important;\
  }'));

  var domHead = document.getElementsByTagName('head')[0];
  domHead.appendChild(bogoStyle);
}
