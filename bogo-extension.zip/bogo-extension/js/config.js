/**
 * Global config object for the extension
 * @author vietnh
 */
var bogoConfig = {
  extensionID: 'inihcaocaeffdlmfhanmabckofdmljee',
  v4ApiUrl: 'https://extension.bogo.vn/v1/',
  v5ApiUrl: 'https://extension.bogo.vn/v1/checkListDomains',
  v6ApiUrl: 'https://extension.bogo.vn/v1/getSubContent',
  bogoDomain: 'https://www.bogo.vn',
  bogoLoginUrl: 'https://www.bogo.vn/login',
  bogoLogoutUrl: 'https://www.bogo.vn/logout',
  cookieName: 'bogo_user_info',
  environment: 'dev', // change to prod when everything of bogo.vn is okay
  contentType: 'application/x-www-form-urlencoded',
  sampleCookie: 'V1B0Z0dQLTE2YzExYQ%3D%3D', // A sample cookie value to use when environment is 'dev'
  cspDomains: [ // Sites that apply content security policy. For now we do not make any AJAX calls when entering those domains.
    'www.facebook.com'
  ],
  dateFormat: 'DD/MM/YYYY',
  text: {
    activate: 'Kích hoạt',
    activateLater: 'Để sau',
    loginToActivate: 'Đăng nhập để kích hoạt',
    availableCoupons: 'mã coupons',
    upTo: 'Up to ',
    cashBack: 'Cash Back',
    getCode: 'Lấy Code',
    getDeal: 'Xem deal',
    today: 'Hôm nay',
    discount: 'giảm'
  }
};
