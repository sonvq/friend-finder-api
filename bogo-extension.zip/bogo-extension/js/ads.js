// Add script for google search results
var domain = window.location.hostname;
// Apply with only google.com domain
if (domain.indexOf('www.google.com') > -1) {
  window.addEventListener('message', function onMessage(e) {

    // When a search result is occured
    if (typeof e.data === 'object' && e.data.type === 'sr') {
      var http = new XMLHttpRequest();
      var params = "siteName=google&url=" + encodeURIComponent(window.location.href);
      http.open("POST", bogoConfig.v6ApiUrl, true);
      http.setRequestHeader("Content-type", bogoConfig.contentType);

      http.onreadystatechange = function() {
        if(http.readyState == 4 && http.status == 200) {
          var response = JSON.parse(http.responseText);

          // If there is no error
          if (! response.code && response.data.length) {
            var content = response.data[0].content;
            if (content) {
              var rso = document.getElementById('rso');
              if (rso) {
                rso.insertAdjacentHTML('afterbegin', '<div class="srg"><div class="g">' + content + "</div></div>");
              }
            }
          }
        }
      };

      http.send(params);
    }
  });
} else if (domain.indexOf('www.facebook.com') === -1) {
  // Set timeout to avoid conflict between ajax requests
  setTimeout(function() {
    var http = new XMLHttpRequest();
    var params = "siteName=facebook";
    http.open("POST", bogoConfig.v6ApiUrl, true);
    http.setRequestHeader("Content-type", bogoConfig.contentType);

    http.onreadystatechange = function() {
      if(http.readyState == 4 && http.status == 200) {
        var response = JSON.parse(http.responseText);

        // If there is no error
        if (! response.code && response.data.length) {
          var content = response.data[0].content;
          if (content) {
            // Fire an event to pass ad content from ajax response
            var customEvent = document.createEvent('Event');
            customEvent.initEvent('bogoAd', true, true);

            var hiddenDiv = document.getElementById('bogo-facebook-ad');
            hiddenDiv.innerText = content;
            hiddenDiv.dispatchEvent(customEvent);
          }
        }
      }
    };

    http.send(params);
  }, 1000);
}
