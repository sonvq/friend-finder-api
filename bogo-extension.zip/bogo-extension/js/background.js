/**
 * Background script to control the state of the extension
 * @author vietnh
 */
// Pass cookie via chrome messaging
chrome.cookies.get({ 'url': bogoConfig.bogoDomain, 'name': bogoConfig.cookieName }, function(cookie) {
  var cookieValue = cookie ? cookie.value : null;
  
  chrome.runtime.onConnect.addListener(function(port) {
    port.onMessage.addListener(function(request) {
      // pass message contains bogo cookie
      if (request.api == 'cookie') {
        port.postMessage({ user: cookieValue });
      }
    });
  });
});
