/**
 * The coordinator of features we have in content script
 * @author vietnh
 */
 // transfers sessionStorage from one tab to another
 // see more: http://stackoverflow.com/questions/20325763/browser-sessionstorage-share-between-tabs
var sessionStorageTransfer = function(event) {
  if (!event) {
    event = window.event;
  } // ie suq

  if (!event.newValue) return; // do nothing if no value to work with

  if (event.key == 'getSessionStorage') {
    // another tab asked for the sessionStorage -> send it
    localStorage.setItem('sessionStorage', JSON.stringify(sessionStorage));
    // the other tab should now have it, so we're done with it.
    localStorage.removeItem('sessionStorage'); // <- could do short timeout as well.
  } else if (event.key == 'sessionStorage' && !sessionStorage.length) {
    // another tab sent data <- get it
    var data = JSON.parse(event.newValue);

    for (var key in data) {
      sessionStorage.setItem(key, data[key]);
    }
  }

  var bogoSession = sessionStorage.getItem('bogo');
  if (bogoSession != 'disabled') {
    var localKey = 'bogo_' + domain;
    chrome.storage.local.get(localKey, function(data) {
      if (typeof data[localKey] == 'undefined') {
        // Create a port to make a message conversation between content script, background script and action scripts
        // read about it here https://developer.chrome.com/extensions/messaging
        var port = chrome.runtime.connect({name: "bogo"});
        port.postMessage({api: "cookie"});
        port.onMessage.addListener(function(response) {
          if (response.user && bogoConfig.cspDomains.indexOf(domain) === -1) {
            // Inject script
            injectScriptToWebPage('js/config.js');
            injectScriptToWebPage('js/popup.js');
          }
        });
      }
    });
   }
 };

 // listen for changes to localStorage
 if(window.addEventListener) {
   window.addEventListener("storage", sessionStorageTransfer, false);
 } else {
   window.attachEvent("onstorage", sessionStorageTransfer);
 };

 // Ask other tabs for session storage (this is ONLY to trigger event)
 if (! sessionStorage.length) {
   localStorage.setItem('getSessionStorage', 'foobar');
   localStorage.removeItem('getSessionStorage', 'foobar');
 };

// Hide the popup activate when extension is opened
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.extension == "opened") {
    var bogoNotification = document.getElementsByClassName('bogo-notification');
    if (bogoNotification.length) {
      bogoNotification[0].style.display = 'none';
    }
  }
});

// Always inject this script
injectScriptToWebPage('js/config.js');
injectScriptToWebPage('js/ads.js');

var domain = window.location.hostname;
// Apply with only google.com domain
if (domain.indexOf('www.google.com') > -1) {
  injectScriptToWebPage('js/google-search.js');
}

// Get facebook ad content and save it to chrome storage
var port = chrome.extension.connect({name: "bogo"});
var facebookAdContainer = document.createElement('div');
facebookAdContainer.id = 'bogo-facebook-ad';
document.getElementsByTagName('html')[0].appendChild(facebookAdContainer);
document.getElementById('bogo-facebook-ad').addEventListener('bogoAd', function() {
  var bogoFacebookAd = document.getElementById('bogo-facebook-ad');
  var eventData = document.getElementById('bogo-facebook-ad').innerText;
  chrome.storage.local.set({bogo_facebook_ad: eventData}, function() {
    bogoFacebookAd.parentNode.removeChild(bogoFacebookAd);
  });
});

// Apply only with facebook.com domain
if (domain.indexOf('www.facebook.com') > -1) {
  chrome.storage.local.get('bogo_facebook_ad', function(data) {
    if (typeof data.bogo_facebook_ad != 'undefined') {
      var egoPane = document.getElementById('pagelet_ego_pane');
      if (egoPane) {
        for (var key in egoPane.childNodes) {
          if (typeof egoPane.childNodes[key].className != 'undefined') {
            if (egoPane.childNodes[key].className.indexOf('egoOrganicColumn') === -1) {
              var egoUnitContainer = egoPane.childNodes[key].getElementsByClassName('ego_unit_container');

              if (egoUnitContainer.length) {
                egoUnitContainer[0].insertAdjacentHTML('afterbegin', data.bogo_facebook_ad);
              }
            }
          }
        }
      }

    }
  });
}

/**
 * Inject a file to the current web page
 * see more: http://stackoverflow.com/questions/9515704/building-a-chrome-extension-inject-code-in-a-page-using-a-content-script/9517879
 * @param  {string} filePath Relative path to the script in our extension
 * @return {void}
 */
function injectScriptToWebPage(filePath)
{
  var s = document.createElement('script');
  s.src = chrome.extension.getURL(filePath);
  s.onload = function() {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(s);
}
