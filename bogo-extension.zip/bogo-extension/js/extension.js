/**
 * Script for handling extension in context of a non-affiliate site
 * @author vietnh
 */
// Send a message to content script to notify that the extension popup was opened
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  chrome.tabs.sendMessage(tabs[0].id, {extension: "opened"}, function(response) {
    console.log('sent to content script.');
  });
});
chrome.storage.local.clear(function() {
    var error = chrome.runtime.lastError;
    if (error) {
        console.error(error);
    }
});
if (!chrome.cookies) {
  chrome.cookies = chrome.experimental.cookies;
}

// Get bogo user cookie
chrome.cookies.get({ 'url': bogoConfig.bogoDomain, 'name': bogoConfig.cookieName }, function(cookie) {
  // Get current domain and make AJAX requests
  chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
    // Get current domain
    var url = tabs[0].url;
    var domain = url.match(/^[\w-]+:\/{2,}\[?([\w\.:-]+)\]?(?::[0-9]*)?/)[1];

    // Make AJAX requests
    var http = new XMLHttpRequest();
    var params = "domain=" + domain + "&getFullData=true";
    if (cookie) {
      if (bogoConfig.environment == 'prod') {
        params += "&user=" + cookie.value;
      } else {
        params += '&user=' + bogoConfig.sampleCookie;
      }
    }

    http.open("POST", bogoConfig.v4ApiUrl, true);
    http.setRequestHeader("Content-type", bogoConfig.contentType);

    http.onreadystatechange = function() {
      if(http.readyState == 4 && http.status == 200) {
        var response = JSON.parse(http.responseText);
        // If there is no error
        if (! response.code) {

          // Get all coupons and append them to DOM
          // Coupons maybe from topCouponByFavoriteStores (logged-in users) or topCoupons (not logged-in users)
          var coupons = response.data.topCouponByFavoriteStores;
          var favorite = true;
          if (! coupons) {
            coupons = response.data.topCoupons;
            var favorite = false;
          }

          // Not affiliate page
          if (! response.data.storeInfo) {
            var activeTab = $('#tab-cashback1');
          } else {
            var activeTab = $('#tab-cashback2');
            activeTab.show().addClass('active');
            $('.cashback2').parent().addClass('active').show();
            $('#tab-cashback1').remove();
            $('.cashback1').remove();
          }

          if (coupons) {
            if (favorite) {
              $('.cashback1').text('Yêu thích');
            }
            $.each(coupons, function(k, v) {
              var upTo = v['store.up_to'] ? 'Up to ' : '';
              var cashBack = v['store.cash_back'] ? v['store.cash_back'] + v['store.currency'] + ' ' : '';
              var desc = v['coupon.title'] ? v['coupon.title'] : '';
              var expireDate = getExpirationDate(v['coupon.expire_date'], 'pull-right');
              var affiliateUrl = cookie ? v['coupon.affiliate_url'] : bogoConfig.bogoLoginUrl;
              var discount = '';
              if (v['coupon.code']) {
                var couponText = '<a class="btn btn-blue" href="' + affiliateUrl + '" target="__blank">' + bogoConfig.text.getCode + '</a>';
              } else {
                var couponText = '<a class="btn btn-green-low get-code" target="__blank" href="' + affiliateUrl + '">' + bogoConfig.text.getDeal + '</a>';
              }

              // Display discount price, discount percent if not null
              if (v['coupon.origin_price'] && v['coupon.discount_price'] && v['coupon.discount_percent']) {
                discount = '<div class="item-row discount">' + formatNumber(v['coupon.discount_price']) + 'đ <span>(' + bogoConfig.text.discount + ' ' + v['coupon.discount_percent'] + '%)</span></div>';
              }

              activeTab.find('.item-list').append('<div class="item">\
                <div class="item-img"><img src="' + v['store.logo'] + '" alt="logo" /></div>\
                <div class="item-content">\
                  <div class="item-row">\
                    <span class="text-orange">' + upTo + cashBack + '<span class="text-gray">' + bogoConfig.text.cashBack + '</span></span>' + expireDate + '\
                  </div>\
                  <div class="item-row item-desc">' + v['coupon.title'] + '</div>' + discount + '\
                  <div class="item-row item-row-right">' + couponText + '</div>\
                </div>');
            });
          }

          // Get all stores and append them to DOM
          if (response.data.topStoresCashBack) {
            $.each(response.data.topStoresCashBack, function(k, v) {
              var upTo = v.up_to ? bogoConfig.text.upTo : '';
              var cashBack = v.cash_back_percent ? v.cash_back_percent + '% ' : '';

              $('#tab-stores .store-list ul').append('<li>\
                  <div class="store-item">\
                    <a href="' + v.bogo_url + '" target="__blank">\
                      <img src="' + v.logo + '" alt="logo" />\
                      <span class="text-orange">' + upTo + cashBack + '<span class="text-gray">' + bogoConfig.text.cashBack + '</span></span>\
                    </a>\
                  </div>\
                </li>');
            });
          }

          // Update store info to the header
          if (response.data.storeInfo) {
            $('.header > .logo').hide();
            $('.header > .store-current').show();

            $('.store-current-img img').attr('src', response.data.storeInfo.logo);
            if (response.data.storeInfo.cashBack && response.data.storeInfo.cashBack.cashBack) {

              var upTo = response.data.storeInfo.cashBack.upTo ? bogoConfig.text.upTo : '';
              var cashBack = response.data.storeInfo.cashBack.cashBack + response.data.storeInfo.cashBack.currency;

              $('.store-current-cashback')
                .append('<span class="text-orange">' + upTo + cashBack + ' <span class="text-gray">' + bogoConfig.text.cashBack + '</span></span>');

              // Align center those blocks
              $('.store-current-row').addClass('text-center');
              $('.store-current-content').addClass('auto-margin');

            } else if (response.data.storeInfo.couponsAvailable){

              $('.store-current-cashback')
                .append('<span class="text-orange">' + response.data.storeInfo.couponsAvailable + ' ' + bogoConfig.text.availableCoupons + '</span>');
            }

            if (! cookie || ! response.data.userInfo) {
              // $('.store-current-row').removeClass('text-center');
              $('.store-current-link a').attr('href', bogoConfig.bogoLoginUrl).text(bogoConfig.text.loginToActivate);
            }
          }

          // Get all coupons and append them to DOM
          if (response.data.couponsInStore) {
            $.each(response.data.couponsInStore, function(k, v) {
              var desc = v.title ? v.title : '';
              var expireDate = getExpirationDate(v.expire_date);
              var affiliateUrl = cookie ? v.affiliate_url : bogoConfig.bogoLoginUrl;

              if (v.code) {
                var couponText = 'Lấy code';
                // if (cookie) {
                  chrome.storage.local.get('bogo', function(data) {
                    var storage = [];

                    if (typeof data.bogo != 'undefined') {
                      storage = JSON.parse(data.bogo);
                      if (data.bogo.indexOf(v.code) > -1) {
                        couponText = v.code;
                      }
                    }

                    activeTab.find('.item-list').append('<div class="item">\
                        <div class="item-row item-desc">' + desc + '</div>\
                        <div class="item-row item-row-right">' + expireDate + '\
                            <a class="btn btn-blue get-code" target="__blank" href="' + affiliateUrl + '" data-code="' + v.code + '">' + couponText + '</a>\
                        </div>\
                      </div>');

                    $(document).off('click', '.get-code').on('click', '.get-code', function(e) {
                      e.preventDefault();
                      storage.push($(this).attr('data-code'));
                      chrome.storage.local.set({ 'bogo': JSON.stringify(storage) }, function() {
                        window.open(affiliateUrl);
                      });
                    });
                  });
                // }
              } else {
                var couponText = bogoConfig.text.getDeal;

                activeTab.find('.item-list').append('<div class="item">\
                    <div class="item-row item-desc">' + desc + '</div>\
                    <div class="item-row item-row-right">' + expireDate + '\
                        <a class="btn btn-green-low get-code" target="__blank" href="' + affiliateUrl + '">' + couponText + '</a>\
                    </div>\
                  </div>');
              }

            });
          }

          // Add user information
          if (cookie && response.data.userInfo) {
            if (response.data.storeInfo) {
              // Update header
              $('.store-current').addClass('login');
              $('.store-current-link').remove();
              $('.store-current-row').removeClass('text-center');
              if (response.data.storeInfo) {
                var activateLink = $('.store-current-check').show().find('a');
                activateLink.attr('href', response.data.storeInfo.affiliateUrl);
                var localKey = 'bogo_' + domain;
                chrome.storage.local.get(localKey, function(data) {
                  if (typeof data[localKey] != 'undefined') {
                    activateLink.removeClass('btn-orange-solid').addClass('btn-green-low-solid');
                    activateLink.append('<i class="icon-check-white icon-right"></i>');
                  }
                });

                activateLink.on('click', function(e) {
                  e.preventDefault();
                  var that = this;
                  var localObject = {};
                  localObject[localKey] = 'true';
                  chrome.storage.local.get(localKey, function(data) {
                    if (typeof data[localKey] == 'undefined') {
                      chrome.storage.local.set(localObject, function() {
                        activateLink.removeClass('btn-orange-solid').addClass('btn-green-low-solid');
                        activateLink.append('<i class="icon-check-white icon-right"></i>');

                        chrome.tabs.getSelected(null, function(tab) {
                          var code = 'window.location.reload();';
                          chrome.tabs.executeScript(tab.id, {code: code});
                        });
                      });
                    }
                  });
                });
              }
            }
            $('.footer').show();
            if (response.data.userInfo.fullName) {
              $('.username').append('<i class="icon-user icon-left"></i>' + response.data.userInfo.fullName);
            }

            if (typeof response.data.userInfo.totalCashBack != 'undefined') {
              $('.user-cashback').append('<i class="icon-money icon-left"></i>' + formatNumber(String(response.data.userInfo.totalCashBack)) + '₫');
            }

            $('.user-logout').attr('href', bogoConfig.bogoLogoutUrl);
          }

          var hrefs = $("a");


        } else {
          console.log(response.msg);
        }
      }
    }
    http.send(params);
  });
});

/**
 * Format and return expiration date
 * @param   string date
 * @param   string additionalClass
 * @return  string
 */
function getExpirationDate(date, additionalClass)
{
  additionalClass = typeof additionalClass == 'undefined' ? '' : additionalClass;

  if (date) {
    var formattedDate = moment(date).format(bogoConfig.dateFormat);

    // Red text and icon for today
    if (formattedDate == moment().format(bogoConfig.dateFormat)) {
      return '<span class="' + additionalClass + ' text-red"><i class="icon-clock-red icon-left"></i>' + bogoConfig.text.today + '</span>';
    }

    return '<span class="' + additionalClass + ' text-gray"><i class="icon-clock-gray icon-left"></i>' + formattedDate + '</span>';;
  }

  return  '<span class="' + additionalClass + ' text-gray"></span>';
}

/**
 * Format number, e.g. 100000 to 100.000
 * @param string number
 * @return string
 */
function formatNumber(number)
{
  number += '';
  x = number.split('.');
  x1 = x[0];
  x2 = x.length > 1 ? '.' + x[1] : '';
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
      x1 = x1.replace(rgx, '$1' + '.' + '$2'); // changed comma to dot here
  }

  return x1 + x2;
}
