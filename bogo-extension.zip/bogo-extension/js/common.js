//tab click
$('.tabs-title ul li a').on('click',function(e) {
  e.preventDefault();
  var href = $(this).attr('href');
  var parent = $(this).parent();
  if(!parent.hasClass('active')) {
    $('.tabs-title ul li.active').removeClass('active');
    parent.addClass('active');
    $('.tabs-pane.active').hide().removeClass('active');
    $(href).show().addClass('active');
  }
});

$('.tabs-content').slimScroll({height: '351px', railVisible: true});
