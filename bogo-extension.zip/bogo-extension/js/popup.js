/**
 * Content script to auto open a popup in affliate site with cashback
 * @author vietnh
 */

// Get domain name
var domain = window.location.hostname;
// Make AJAX request
var http = new XMLHttpRequest();
var params = "domain=" + domain + "&getFullData=false";

http.open("POST", bogoConfig.v4ApiUrl, true);
http.setRequestHeader("Content-type", bogoConfig.contentType);

http.onreadystatechange = function() {
  if(http.readyState == 4 && http.status == 200) {
    var response = JSON.parse(http.responseText);
    // If there is no error
    if (! response.code) {
      var cashBack = response.data.storeInfo && response.data.storeInfo.cashBack && response.data.storeInfo.cashBack.cashBack ?
        response.data.storeInfo.cashBack.cashBack + response.data.storeInfo.cashBack.currency : '';
      if (! cashBack) {
        return false;
      }

      var domHtml = document.getElementsByTagName('html')[0];
      // Append the bogo notification pop to the end of html tag
      createBogoNotificationPopup(domHtml, cashBack);

      // Delegate events
      delegateBogoEvents(domHtml, response.data.storeInfo.affiliateUrl);

      // Append style of the popup to head
      // Style and HTML was copied from Ebates Extension
      addCssStyleToPopup();
    } else {
      console.log(response.msg);
    }
  }
}

http.send(params);

/**
 * Create bogo notification popup and append it the DOM
 */
function createBogoNotificationPopup(domHtml, cashBack)
{
  var bogoNotification = document.createElement('div');
  bogoNotification.className = 'bogo-notification';
  var bogoNotificationPanel = document.createElement('div');
  bogoNotificationPanel.className = 'bogo-notification-panel';
  var bogoNotificationLogoBg = document.createElement('div');
  bogoNotificationLogoBg.className = 'bogo-notification-logo-bg';
  var bogoNotificationLogo = document.createElement('div');
  bogoNotificationLogo.className = 'bogo-notification-logo';
  var bogoNotificationLogoBgArrow = document.createElement('div');
  bogoNotificationLogoBgArrow.className = 'bogo-notification-logo-bg-arrow';
  var bogoNotificationBody = document.createElement('div');
  bogoNotificationBody.className = 'bogo-notification-body';
  var bogoNotifactionButton = document.createElement('div');
  bogoNotifactionButton.className = 'bogo-notification-button bogo-notification-button-activate';
  var bogoNotifactionButtonText = document.createTextNode(bogoConfig.text.activate + ' ' + cashBack + ' Cash Back');
  var bogoNotificationCloseCenter = document.createElement('center');
  var bogoNotificationClose = document.createElement('span');
  bogoNotificationClose.className = 'bogo-notification-close';
  var bogoNotificationCloseText = document.createTextNode(bogoConfig.text.activateLater);

  bogoNotifactionButton.appendChild(bogoNotifactionButtonText);
  bogoNotificationClose.appendChild(bogoNotificationCloseText);
  bogoNotificationBody.appendChild(bogoNotifactionButton);
  bogoNotificationBody.appendChild(bogoNotificationClose);

  bogoNotificationLogoBg.appendChild(bogoNotificationLogo);
  bogoNotificationLogoBg.appendChild(bogoNotificationLogoBgArrow);

  bogoNotificationPanel.appendChild(bogoNotificationLogoBg);
  bogoNotificationPanel.appendChild(bogoNotificationBody);

  bogoNotification.appendChild(bogoNotificationPanel);
  domHtml.appendChild(bogoNotification);
}

/**
 * Delete event listener to bogo buttons
 */
function delegateBogoEvents(domHtml, affiliateUrl)
{
  domHtml.addEventListener('click', function(e) {
    if (e.target) {
      // Delegate click event to bogo notification Button
      if (e.target.className.indexOf('bogo-notification-button') > -1) {
        document.getElementsByClassName('bogo-notification')[0].style.display = 'none';
        window.open(affiliateUrl);
      }

      // Delegate click event to 'Activate Later' button
      if (e.target.className.indexOf('bogo-notification-close') > -1) {
        document.getElementsByClassName('bogo-notification')[0].style.display = 'none';
        sessionStorage.setItem('bogo', 'disabled');
      }
    }
  });
}

/**
 * Add CSS Style to head of html page for the 'Activate' notification popup of Bogo
 */
function addCssStyleToPopup()
{
  var bogoStyle = document.createElement('style');
  bogoStyle.appendChild(document.createTextNode('div.bogo-notification {\
    position: fixed;\
    right: 10px;\
    border-radius: 4px;\
    box-shadow: rgba(0,0,0,.5) 0 0 10px;\
    background: #fff;\
    font-size: 100%;\
    overflow: hidden;\
    z-index: 2147483647!important;\
    max-width: 410px;\
    box-sizing: content-box!important;\
    opacity: 1;\
    top: 10px;\
  }\
  div.bogo-notification .bogo-notification-panel {\
    display: -webkit-flex;\
    display: -moz-flex;\
    display: -ms-flexbox;\
    display: -ms-flex;\
    display: flex;\
    -webkit-flex-direction: row;\
    -moz-flex-direction: row;\
    -ms-flex-direction: row;\
    flex-direction: row;\
    -webkit-align-content: center;\
    -moz-align-content: center;\
    -ms-align-content: center;\
    align-content: center;\
    -webkit-align-items: center;\
    -moz-align-items: center;\
    -ms-align-items: center;\
    align-items: center;\
  }\
  div.bogo-notification * {\
    box-sizing: content-box!important;\
    vertical-align: initial;\
    line-height: normal;\
    padding: 0;\
    margin: 0;\
  }\
  div.bogo-notification .bogo-notification-logo-bg {\
    background-color: #0A7BA3;\
    padding: 0 16px;\
    position: relative;\
    width: 110px;\
    height: 92px;\
    display: flex;\
    align-items: center;\
  }\
  div.bogo-notification .bogo-notification-logo {\
    display: inline-block!important;\
    width: 66px!important;\
    height: 35px!important;\
    margin: 0!important;\
    background-image: url("https://www.bogo.vn/static/images/bogo-logo.svg") !important;\
    background-size: cover;\
  }\
  div.bogo-notification .bogo-notification-logo-bg .bogo-notification-logo-bg-arrow {\
    position: absolute!important;\
    right: 0!important;\
    top: 0!important;\
    border-top: 46px solid #fff!important;\
    border-bottom: 46px solid #fff!important;\
    border-left: 26px solid #0A7BA3!important;\
  }\
  div.bogo-notification .bogo-notification-panel .bogo-notification-body {\
    display: -webkit-flex;\
    display: -moz-flex;\
    display: -ms-flexbox;\
    display: -ms-flex;\
    display: flex;\
    -webkit-flex-direction: column;\
    -moz-flex-direction: column;\
    -ms-flex-direction: column;\
    flex-direction: column;\
  }\
  div.bogo-notification .bogo-notification-button.bogo-notification-button-activate {\
    text-shadow: -1px -1px 0 #a84155!important;\
    color: #fff!important!important;\
    background: #D25068!important;\
    border: 1px solid #D25068!important;\
    background-image: linear-gradient(to bottom,#f66c7b,#d25068)!important;\
    border-radius: 5px!important;\
    box-shadow: 0 1px 0 rgba(255,255,255,.5) inset,0 -1px 0 rgba(255,255,255,.1) inset,0 4px 0 #ad4257,0 4px 2px rgba(0,0,0,.5)!important;\
  }\
  div.bogo-notification .bogo-notification-button {\
    position: relative;\
    cursor: pointer;\
    min-width: 220px;\
    min-height: 40px;\
    text-align: center;\
    color: #FFF!important;\
    text-decoration: none;\
    line-height: 20px;\
    font-family: Roboto,sans-serif;\
    font-weight: 700;\
    font-size: 15px;\
    display: block;\
    margin: 4px 8px!important;\
    padding: 0 8px;\
    white-space: nowrap;\
    display: flex;\
    align-items: center;\
    justify-content: center;\
  }\
  div.bogo-notification .bogo-notification-close {\
    background-size: 100%;\
    text-align: center;\
    font-size: 14px;\
    font-family: Roboto,sans-serif;\
    font-weight: 300;\
    color: #888;\
    cursor: pointer;\
    text-decoration: underline;\
    width: 30%;\
    margin: 0 auto;\
  }'));

  var domHead = document.getElementsByTagName('head')[0];
  domHead.appendChild(bogoStyle);
}
